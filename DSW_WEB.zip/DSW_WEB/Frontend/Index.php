<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DSW DTU</title>
    <!-- <link rel="stylesheet" href="styles/navbar.css"> -->
    <link rel="stylesheet" href="./Assets/Css/Index.css">
    <!-- <link rel="stylesheet" href="styles/header.css"> -->
</head>
<body>
    <!-- HEADER STARTS -->
    <section id="header">
        <div class="header">
        <a href="#header" class="header-title">Delhi Technological University</a>
        <img class="DTU_logo"src="./Assets/Images/logo.png" alt="DTU LOGO">
        </div>
    </section>

    <!-- NAVBAR STARTS-->
    <nav>
        <button class="navbar-toggler" type="button" aria-controls="primary-navbar" aria-expanded="false">
            <span class="navbar-toggler-icon"> &#x02261; Menu</span>
        </button>
        <ul id="primary-navbar"class="primary-navbar" data-visible="false">
            <li class="active nav-item" >
                <a class="nav-link" aria-hidden="true" href="Index.php">Home</a>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link " aria-hidden="true" href="#" role="button" >About &#x025BE;</a>
                <div class="dropdown-menu"  >
                    <a class="dropdown-item" href="./About/Vision_Mission.php">Vision & Mission</a>
                    <a class="dropdown-item" href="./About/Message_VC.php">Message from Vice Chancellor</a>
                    <a class="dropdown-item" href="./About/Message_Dean.php">Message from Dean</a>
                    <a class="dropdown-item" href="./About/Brochure.php">Brochure</a>
                </div>

            </li>
            <li class="nav-item dropdown">
                <a  class="nav-link" aria-hidden="true" href="#" id="aboutDropdown" role="button" >
                    Student Activities &#x025BE;
                </a>
                <div class="dropdown-menu"  >
                    <a class="dropdown-item" href="./Student-Activites/Cultural_Council.php">Cultural Council</a>
                    <a class="dropdown-item" href="./Student-Activites/Literary_Council.php">Literary Council</a>
                    <a class="dropdown-item" href="./Student-Activites/Innovative_Team.php">Innovative Team</a>
                    <a class="dropdown-item" href="./Student-Activites/Technical_Council.php">Technical Council</a>
                    <a class="dropdown-item" href="./Student-Activites/Social_Socities.php">Social Societies</a>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link" aria-hidden="true" href="./Guidelines/Notice.php">Guidelines</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" aria-hidden="true" href="./Events/Events.php">Events</a>
            </li >
            <li class="nav-item" >
                <a class="nav-link" aria-hidden="true" href="https://cumsdtu.in/student_dtu/login/login.jsp">Student Portal</a>
            </li >
            <li class="nav-item">
                <a class="nav-link" aria-hidden="true" href="./Guidelines/Notice.php">Notices</a>
            </li>
            <li class="nav-item">
                <a  class="nav-link" aria-hidden="true" href="./Community/Sports_Games.php">Sports & Games</a>
            </li>

        </ul>
    </nav>


<!-- FOOTER STARTS-->
<footer>
        <div class="footer-above">
            <div class="container">
                <div class="row">
                    <div class="footer-col ">
                        <h2>Contact Us: </h2>
                        <p>Tel: 011-27871018</p>
                        <p>Fax: 011-27871023</p>
                    </div>
                    <div class="footer-col ">
                        <h2>Address: </h2>
                        <p>
                            Delhi Technological University
                            <br>Shahbad Daulatpur, Main Bawana Road,
                            <br>Delhi - 110042
                        </p>
                    </div>
                    <div class="footer-col">
                        <h2>Links: </h2>
                        <ul class="footer-linklist">
                            <li>
                                <a class="footer-link-item" href="#">link1</a>
                            </li>
                            <li>
                                <a class="footer-link-item" href="#">link2</a>
                            </li>
                            <li>
                                <a class="footer-link-item" href="#">link3</a>
                            </li>
                        </ul>

                    </div>
                </div>
            </div>
        </div>
        <div class="footer-below">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12"> Copyright © <a href="http://dtu.ac.in" style="color:cornsilk;">Delhi
                            Technological University</a> </div>
                </div>
            </div>
        </div>
    </footer>

   <script src="./Assets/Js/Nav.js"></script> 
</body>
</html>
    
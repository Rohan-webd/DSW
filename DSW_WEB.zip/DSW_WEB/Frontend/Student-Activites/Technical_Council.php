<?php include('../Partials(Reusable)/Navbar.php') ?>
<div class="main_Container_L">
<div class="Cultural_itinery TC">
    <h1>Technical Council</h1>

</div>

<div class="Societies">
    <h1>Societies</h1>
<div class="Card_Soc">
    <div class="Flex_row_3">

    <div class="societ_Card"><img src="../Assets/Images/logo.png" alt="">
    <a href="../Assets/pdf/pdf_1.pdf" target="_blank"><div class="fac_div"><h1>PRATIBIMB</h1>
<p> Faculty: Mrs Saroj Bala</p></div></a>
</div>
<div class="societ_Card"><img src="../Assets/Images/logo.png" alt="">
<a href="../Assets/pdf/pdf_1.pdf" target="_blank">   <div class="fac_div"><h1>VIBE</h1>
<p> Faculty: Prof. N S Raghava </p></div></a>
</div>
<div class="societ_Card"><img src="../Assets/Images/logo.png" alt="">
<a href="../Assets/pdf/pdf_1.pdf" target="_blank">  <div class="fac_div"><h1>PANACHE</h1>
<p> Faculty: Mrs Saroj Bala </p></div>
</a>
</div>
    </div>

    <!--  -->
    <div class="Flex_row_3">

<div class="societ_Card"><img src="../Assets/Images/logo.png" alt="">
<a href="../Assets/pdf/pdf_1.pdf" target="_blank"><div class="fac_div"><h1>BHANGRA</h1>
<p> Faculty: </p></div></a>
</div>
<div class="societ_Card"><img src="../Assets/Images/logo.png" alt="">
<a href="../Assets/pdf/pdf_1.pdf" target="_blank"><div class="fac_div"><h1>PARCHHAYI</h1>
<p> Faculty: Prof. Rajesh Rohilla </p></div></a>
</div>
<div class="societ_Card"><img src="../Assets/Images/logo.png" alt="">
<a href="../Assets/pdf/pdf_1.pdf" target="_blank"><div class="fac_div"><h1>NRITYANGANA</h1>
<p> Faculty: Dr. Rachna Garg </p></div>
</a>
</div>
</div>
    <!--  -->
    <div class="Flex_row_3">

    <div class="societ_Card"><img src="../Assets/Images/logo.png" alt="">
    <a href="../Assets/pdf/pdf_1.pdf" target="_blank"> <div class="fac_div"><h1>MADHURIMA THE MUSIC SOCIETY</h1>
<p> Faculty: Dr. Richa Srivastava</p></div>
</a>
</div>
<div class="societ_Card"><img src="../Assets/Images/logo.png" alt="">
<a href="../Assets/pdf/pdf_1.pdf" target="_blank">   <div class="fac_div"><h1>KALAKRITI</h1>
<p> Faculty: Mr. Rooplal Rana </p></div>
</a>
</div>
<div class="societ_Card"><img src="../Assets/Images/logo.png" alt="">
<a href="../Assets/pdf/pdf_1.pdf" target="_blank">  <div class="fac_div"><h1>FILM CLUB</h1>
<p> Faculty:</p></div>
</a>
</div>
    </div>

    <div class="Flex_row_3">

<div class="societ_Card"><img src="../Assets/Images/logo.png" alt="">
<a href="../Assets/pdf/pdf_1.pdf" target="_blank"><div class="fac_div"><h1>SHIDDAT</h1>
<p> Faculty: Dr. Ratnam Mishra</p></div>
</a>
</div>
</div>

    </div>
</div>

</div>

<?php include('../Partials(Reusable)/Footer.php') ?>
    
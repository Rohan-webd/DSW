<?php include('../Partials(Reusable)/Navbar.php') ?>

<div class="main_Container_L">
<div class="Cultural_itinery IT">
    <h1>Innovative Team</h1>
</div>

<div class="Societies">
    <h1>Societies</h1>
<div class="Card_Soc">
    <div class="Flex_row_3">

    <div class="societ_Card"><img src="../Assets/Images/logo.png" alt="">
    <a href="../Assets/pdf/pdf_1.pdf" target="_blank"><div class="fac_div"><h1>TEAM INFERNO</h1>
<p> Faculty: Prof. P K Jain</p></div></a>
</div>
<div class="societ_Card"><img src="../Assets/Images/logo.png" alt="">
<a href="../Assets/pdf/pdf_1.pdf" target="_blank">   <div class="fac_div"><h1>TEAM RAFTAR</h1>
<p> Faculty: Prof. Rajesh Kumar </p></div></a>
</div>
<div class="societ_Card"><img src="../Assets/Images/logo.png" alt="">
<a href="../Assets/pdf/pdf_1.pdf" target="_blank">  <div class="fac_div"><h1>UAS-DTU</h1>
<p> Faculty: Prof. N S Raghava </p></div>
</a>
</div>
    </div>

    <!--  -->
    <div class="Flex_row_3">

<div class="societ_Card"><img src="../Assets/Images/logo.png" alt="">
<a href="../Assets/pdf/pdf_1.pdf" target="_blank"><div class="fac_div"><h1>TEAM SUPER MILEAGE</h1>
<p> Faculty: Prof. A K Aggarwal </p></div></a>
</div>
<div class="societ_Card"><img src="../Assets/Images/logo.png" alt="">
<a href="../Assets/pdf/pdf_1.pdf" target="_blank"><div class="fac_div"><h1>DELTECH BAJA</h1>
<p> Faculty: Prof. M M Tripathi </p></div></a>
</div>
<div class="societ_Card"><img src="../Assets/Images/logo.png" alt="">
<a href="../Assets/pdf/pdf_1.pdf" target="_blank"><div class="fac_div"><h1>DEFIANZ RACING TEAM</h1>
<p> Faculty: Dr. Qasim Mortaza </p></div>
</a>
</div>
</div>
    <!--  -->
    <div class="Flex_row_3">

    <div class="societ_Card"><img src="../Assets/Images/logo.png" alt="">
    <a href="../Assets/pdf/pdf_1.pdf" target="_blank"> <div class="fac_div"><h1>UGV-DTU</h1>
<p> Faculty: Dr. S Indu</p></div>
</a>
</div>
<div class="societ_Card"><img src="../Assets/Images/logo.png" alt="">
<a href="../Assets/pdf/pdf_1.pdf" target="_blank">   <div class="fac_div"><h1>AUV</h1>
<p> Faculty: </p></div>
</a>
</div>
<div class="societ_Card"><img src="../Assets/Images/logo.png" alt="">
<a href="../Assets/pdf/pdf_1.pdf" target="_blank">  <div class="fac_div"><h1>OKAMI RACING</h1>
<p> Faculty:</p></div>
</a>
</div>
    </div>

    <div class="Flex_row_3">

<div class="societ_Card"><img src="../Assets/Images/logo.png" alt="">
<a href="../Assets/pdf/pdf_1.pdf" target="_blank"><div class="fac_div"><h1>ALTAIR</h1>
<p> Faculty: </p></div>
</a>
</div>
<div class="societ_Card"><img src="../Assets/Images/logo.png" alt="">
<a href="../Assets/pdf/pdf_1.pdf" target="_blank">   <div class="fac_div"><h1>HERTZ ELECTRIC</h1>
<p> Faculty:  </p></div>
</a>
</div>
<div class="societ_Card"><img src="../Assets/Images/logo.png" alt="">
<a href="../Assets/pdf/pdf_1.pdf" target="_blank">   <div class="fac_div"><h1>CASRAE</h1>
<p> Faculty:  </p></div>
</a>
</div>
</div>

    </div>
</div>

</div>
<?php include('../Partials(Reusable)/Footer.php') ?>
    
<?php include('../Partials(Reusable)/Navbar.php') ?>
<div class="main_Container_L">
<div class="Cultural_itinery">
    <h1>Literary Council</h1>
<img src="../Assets/Images/literary.png" alt="">

</div>

<div class="Societies">
    <h1>Societies</h1>
<div class="Card_Soc">
    <div class="Flex_row_3">

    <div class="societ_Card"><img src="../Assets/Images/logo.png" alt="">
    <a href="../Assets/pdf/pdf_1.pdf" target="_blank"><div class="fac_div"><h1>SAHITYA</h1>
<p> Faculty: Dr.Yogita Kalra</p></div></a>
</div>
<div class="societ_Card"><img src="../Assets/Images/logo.png" alt="">
<a href="../Assets/pdf/pdf_1.pdf" target="_blank">   <div class="fac_div"><h1>YUVAAN</h1>
<p> Faculty: </p></div></a>
</div>
<div class="societ_Card"><img src="../Assets/Images/logo.png" alt="">
<a href="../Assets/pdf/pdf_1.pdf" target="_blank">  <div class="fac_div"><h1>DTU TIMES</h1>
<p> Faculty: </p></div>
</a>
</div>
    </div>

    <!--  -->
    <div class="Flex_row_3">

<div class="societ_Card"><img src="../Assets/Images/logo.png" alt="">
<a href="../Assets/pdf/pdf_1.pdf" target="_blank"><div class="fac_div"><h1>COGNITIVE MINDS</h1>
<p> Faculty: Ms. Meha Joshi</p></div></a>
</div>
<div class="societ_Card"><img src="../Assets/Images/logo.png" alt="">
<a href="../Assets/pdf/pdf_1.pdf" target="_blank"><div class="fac_div"><h1>TOAST MASTERS</h1>
<p> Faculty: Prof. AK Aggarwal </p></div></a>
</div>
<div class="societ_Card"><img src="../Assets/Images/logo.png" alt="">
<a href="../Assets/pdf/pdf_1.pdf" target="_blank"><div class="fac_div"><h1>ASES</h1>
<p> Faculty: Mr. Rohit Kumar </p></div>
</a>
</div>
</div>
    <!--  -->
    <div class="Flex_row_3">

    <div class="societ_Card"><img src="../Assets/Images/logo.png" alt="">
    <a href="../Assets/pdf/pdf_1.pdf" target="_blank"> <div class="fac_div"><h1>YES + HAPPINESS</h1>
<p> Faculty: Prof. M.M. Tripathi</p></div>
</a>
</div>
<div class="societ_Card"><img src="../Assets/Images/logo.png" alt="">
<a href="../Assets/pdf/pdf_1.pdf" target="_blank">   <div class="fac_div"><h1>CUBIX DTU</h1>
<p> Faculty: </p></div>
</a>
</div>
<div class="societ_Card"><img src="../Assets/Images/logo.png" alt="">
<a href="../Assets/pdf/pdf_1.pdf" target="_blank">  <div class="fac_div"><h1>DEL TECH MUN & DEBATING SOCIETY</h1>
<p> Faculty: Prof. Nao Kant Deo</p></div>
</a>
</div>
    </div>

    <div class="Flex_row_3">

<div class="societ_Card"><img src="../Assets/Images/logo.png" alt="">
<a href="../Assets/pdf/pdf_1.pdf" target="_blank"><div class="fac_div"><h1>QUIZ CLUB</h1>
<p> Faculty: Dr.Mini Shreejeeth</p></div>
</a>
</div>
<div class="societ_Card"><img src="../Assets/Images/logo.png" alt="">
<a href="../Assets/pdf/pdf_1.pdf" target="_blank"><div class="fac_div"><h1>GYI</h1>
<p> Faculty: </p></div>
</a>
</div>
<div class="societ_Card"><img src="../Assets/Images/logo.png" alt="">
<a href="../Assets/pdf/pdf_1.pdf" target="_blank"><div class="fac_div"><h1>E-Cell</h1>
<p> Faculty: Prof. M.M. Tripathi </p></div>
</a>
</div>
</div>

    </div>
</div>

</div>
<?php include('../Partials(Reusable)/Footer.php') ?>
    
<?php include('../Partials(Reusable)/Navbar.php') ?>

<div class="container" id="brochure">
    <h1 style="text-align: center;">Brochure</h1>
    <div class="brochure container-fluid">
        <embed src="../Assets/pdf/brochure_21.pdf" width="80%" height="100%" title="Brochure">
    </div>
</div>


<?php include('../Partials(Reusable)/Footer.php') ?>
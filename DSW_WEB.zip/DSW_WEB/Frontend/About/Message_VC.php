<?php include('../Partials(Reusable)/Navbar.php') ?>

<div class="Message_VC">
<div class="Head_VC">
    <h1>Message From Vice Chancellor</h1>
    <div class="Inline"></div>
</div>
<div class="VC_pic">
<img src="../Assets/Images/VC.jpg" alt="">
<div class="cont_VC">
    <p>  <a href="">Professor Jai Prakash Saini </a>  <br><br>
    Vice Chancellor <br><br>
    Delhi Technological University
</p>

</div>

</div>
</div>

<?php include('../Partials(Reusable)/Footer.php') ?>
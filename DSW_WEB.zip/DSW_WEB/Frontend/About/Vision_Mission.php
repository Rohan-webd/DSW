<?php include('../Partials(Reusable)/Navbar.php') ?>
<div class="vm">
  <div class="vision">
        <h1>Vision</h1>
        <p>To deliver student services and to foster a friendly environment that is inclusive, safe and conducive to learning.</p>
    </div>
    <div class="mission">
        <h1>Mission</h1>
        <ul>
            <li>To support student activities and their co-curricular programs</li>
            <li>To collaborate and share responsibilities with other members of the university community to enhance student learning and support student success.</li>
            <li>To facilitate professional growth and community development of Students.</li>
        </ul>
    </div>

</div>



<?php include('../Partials(Reusable)/Footer.php') ?>
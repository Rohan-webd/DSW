<?php include('../Partials(Reusable)/Navbar.php') ?>
<!-- sports event -->
<div class="event-type">
    <div class="event-name">
        <h1>Sports Events
        </h1>
    </div>
    <div class="individual-events">
    <div class="event-desc">
     <div class="event-img">
    <img src="../Assets/Images/Aahvaan.png" alt="event-photo">
    </div>
    <div class="event-date">
        <h4>21</h5>
        <h5>FEB</h6>
        <h6>2021</h6>
    </div>
    <div class="event-desc-text">
    <h3>Aahvaan 2020</h3>
    <p class="EventP">Aahvaan the annual sports tournament of Delhi Technological University was organised from
         21 st   to 23 rd February 2020.</p>
         <div class="readmore-button">
             <a class="readmore-link" href="#">Read More!!</a>
             <p>DTU</p>
         </div>
    </div>
    <div> 
        
    </div>

    </div>
     <div class="event-desc">
     <div class="event-img">
    <img src="../Assets/Images/Aahvaan.png" alt="event-photo">
    </div>
    <div class="event-date">
        <h4>21</h5>
        <h5>FEB</h6>
        <h6>2021</h6>
    </div>
    <div class="event-desc-text">
    <h3>Aahvaan 2020</h3>
    <p class="EventP">Aahvaan the annual sports tournament of Delhi Technological University was organised from
         21 st   to 23 rd February 2020.</p>
         <div class="readmore-button">
             <a class="readmore-link" href="#">Read More!!</a>
             <p>DTU</p>
         </div>
    </div>
    <div> 
        
    </div>

    </div>
     <div class="event-desc">
     <div class="event-img">
    <img src="../Assets/Images/Aahvaan.png" alt="event-photo">
    </div>
    <div class="event-date">
        <h4>21</h5>
        <h5>FEB</h6>
        <h6>2021</h6>
    </div>
    <div class="event-desc-text">
    <h3>Aahvaan 2020</h3>
    <p class="EventP">Aahvaan the annual sports tournament of Delhi Technological University was organised from
         21 st   to 23 rd February 2020.</p>
         <div class="readmore-button">
             <a class="readmore-link" href="#">Read More!!</a>
            <p>DTU</p>
         </div>
    </div>
    <div> 
        
    </div>

    </div>
    </div>
</div>
<!-- technical events -->
<div class="event-type">
    <div class="event-name">
        <h1>Technical Events
        </h1>
    </div>
    <div class="individual-events">
    <div class="event-desc">
     <div class="event-img">
    <img src="../Assets/Images/trickyckts.png" alt="event-photo">
    </div>
    <div class="event-date">
        <h4>8</h5>
        <h5>FEB</h6>
        <h6>2019</h6>
    </div>
    <div class="event-desc-text">
    <h3>Tricky Circuits</h3>
    <p class="EventP">This time DEPTH decided to do some different events i.e. the name tricky circuits is given to the event.</p>
         <div class="readmore-button">
             <a class="readmore-link" href="#">Read More!!</a>
             <p>DTU</p>
         </div>
    </div>
    <div> 
        
    </div>

    </div>
     <div class="event-desc">
     <div class="event-img">
    <img src="../Assets/Images/trickyckts.png" alt="event-photo">
    </div>
    <div class="event-date">
        <h4>21</h5>
        <h5>FEB</h6>
        <h6>2019</h6>
    </div>
    <div class="event-desc-text">
    <h3>Tricky Circuits</h3>
    <p class="EventP">This time DEPTH decided to do some different events i.e. the name tricky circuits is given to the event.
    </p>
         <div class="readmore-button">
             <a class="readmore-link" href="#">Read More!!</a>
             <p>DTU</p>
         </div>
    </div>
    <div> 
        
    </div>

    </div>
     <div class="event-desc">
     <div class="event-img">
    <img src="../Assets/Images/trickyckts.png" alt="event-photo">
    </div>
    <div class="event-date">
        <h4>8</h5>
        <h5>FEB</h6>
        <h6>2021</h6>
    </div>
    <div class="event-desc-text">
    <h3>Aahvaan 2020</h3>
    <p class="EventP">This time DEPTH decided to do some different events i.e. the name tricky circuits is given to the event.
    </p>
         <div class="readmore-button">
             <a class="readmore-link" href="#">Read More!!</a>
             <p>DTU<p>
         </div>
    </div>
    <div> 
        
    </div>

    </div>
    </div>
</div>

<?php include('../Partials(Reusable)/Footer.php') ?>

const eventDescText=document.querySelectorAll(".EventP")
for (let i = 0; i < eventDescText.length; i++) {
var newEventDescText=eventDescText[i].innerHTML.substring(0,70)+"...";
eventDescText[i].innerHTML=newEventDescText;
}


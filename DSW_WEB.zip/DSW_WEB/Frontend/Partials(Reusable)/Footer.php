<!-- FOOTER STARTS-->
<footer>
        <div class="footer-above">
            <div class="container">
                <div class="row">
                    <div class="footer-col ">
                        <h2>Contact Us: </h2>
                        <p>Tel: 011-27871018</p>
                        <p>Fax: 011-27871023</p>
                    </div>
                    <div class="footer-col ">
                        <h2>Address: </h2>
                        <p>
                            Delhi Technological University
                            <br>Shahbad Daulatpur, Main Bawana Road,
                            <br>Delhi - 110042
                        </p>
                    </div>
                    <div class="footer-col">
                        <h2>Links: </h2>
                        <ul class="footer-linklist">
                            <li>
                                <a class="footer-link-item" href="#">link1</a>
                            </li>
                            <li>
                                <a class="footer-link-item" href="#">link2</a>
                            </li>
                            <li>
                                <a class="footer-link-item" href="#">link3</a>
                            </li>
                        </ul>

                    </div>
                </div>
            </div>
        </div>
        <div class="footer-below">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12"> Copyright © <a href="http://dtu.ac.in" style="color:cornsilk;">Delhi
                            Technological University</a> </div>
                </div>
            </div>
        </div>
    </footer>
<!-- JavaScript Bundle with Popper -->
<script src="https://unpkg.com/swiper@8/swiper-bundle.min.js"></script>
   <script src="../Assets/Js/Nav.js"></script> 
   <script src="../Assets/Js/Events.js"></script>
</body>
</html>
    
<?php include('../Partials(Reusable)/Navbar.php') ?>

<div class="main_Container">
<div class="heading">
    <h1>Sports and Games</h1>
</div>
<div class="Main_Content">


<!-- Slider main container -->
<div class="swiper">
  <!-- Additional required wrapper -->
  <div class="swiper-wrapper">
    <!-- Slides -->
    <div class="swiper-slide"><div class="sports_bg"></div></div>
    <div class="swiper-slide"><div class="sports_bg1"></div></div>
    <div class="swiper-slide"><div class="sports_bg2"></div></div>
    <div class="swiper-slide"><div class="sports_bg3"></div></div>
    
  <!-- If we need pagination -->
</div>

  <!-- If we need navigation buttons -->
  <div class="swiper-button-prev"></div>
  <div class="swiper-button-next"></div>

  <!-- If we need scrollbar -->

</div>

<div class="Sports_Notice">
    <div class="stripe">

    <h1>Sports News And Events</h1>
    </div>


</div>



</div>

<div class="para_Sports">

<p>Physical education & sports play vital role in achieving the aims and objectives of Education. The students of DTU are provided with excellent facilities and encouraged to take part in the tournaments held in and around N.C.R. Delhi, , particulars, engineering institutions. <br><br>

DTU is having 450 m. track, ground for Football, Hockey, Cricket, two courts for Volely ball, two courts for basketball, three courts for Tennis Iand five courts for Badminton, Table Tennis rooms, Chess Rooms, Carrom Rooms and Gyms are also available in the each hostel of the college campus.<br><br>

With the view to recognize upcoming talented sportsman and sports woman in the college, the Sports Council organizes sports festival ARENA. The festival witnesses the large participation of boys and girls which included atheletics, badminston, table tennis, basketball, carrom, chess, cricket, tennis and volleyball. Prizes and certificates were awarded to the winners. The sports year also involves the organization of the Inter Hostel Tournaments in various games i.e. badminton, basket ball, carrom, chess, cricket, football, table tennis, volleyball and tennis.</p>
</div>

</div>

<?php include('../Partials(Reusable)/Footer.php') ?>
<?php 



$con = mysqli_connect("localhost","root","","dsw");


if($con){

}

else{
    echo "Connection Unsuccessful";
}







?>
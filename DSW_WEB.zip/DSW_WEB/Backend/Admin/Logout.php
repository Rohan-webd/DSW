
<?php
include('Admin/Index.php');

if(isset($_POST['logout'])){


    header('Location:../Admin-login.php')
}




?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DSW_Admin</title>
    <link rel="stylesheet" href="../../Frontend/Assets/Css/Admin.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
</head>
<body>

<div class="top">



<div class="logo"><img src="../../Frontend/Assets/Images/logo.png" alt="logo">
</div>


<h1>DSW_ADMIN PANEL</h1>
<div class="logout_btn">

<button type="submit" name="logout">Logout</button>
</div>

</div>

<div class="main">

<div class="manage">
    <div class="heading"><h1>Events</h1></div>
<div class="manage_cont"><p>15</p>

<a href="Add-events.php"><button class="manage_btn">Manage</button></a>
</div></div>
<div class="manage"><div class="heading"><h1>Notices</h1></div><div class="manage_cont"><p>15</p><a href="Add-Events.php"><button class="manage_btn">Manage</button></a></div></div>
<div class="manage"><div class="heading"><h1>Awards</h1></div><div class="manage_cont"><p>15</p><a href="Add-Events.php"><button class="manage_btn">Manage</button></a></div></div>
</div>


    
</body>
</html>
<?php
include('Database/connect.php');
include('Admin-login.php');

if(isset($_POST['adm-submit'])){


    $username = $_POST['Username'];
    $password = $_POST['Password'];

    $sql = "SELECT * FROM `admin` WHERE Username='$username' AND Password='$password'";

    $result = mysqli_query($con,$sql);

    $count = mysqli_num_rows($result);

    if($count==1){

        echo"Login Success";
        header('Location:Admin/Index.php');
    }
    else{
        echo"Login Failed";
        header('Location:Admin-login.php');
    }

}
else{
    echo"Error";
}






?>

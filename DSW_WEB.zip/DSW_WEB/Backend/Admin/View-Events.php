<?php
include('../Database/connect.php') ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View_events</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>
<body>

<table class="table table-bordered">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Title</th>
      <th scope="col">Content</th>
      <th scope="col">Image</th>
      <th scope="col">Active</th>
      <th scope="col">Created at</th>
    </tr>
  </thead>
  <tbody>
      <?php
      
      $events = "SELECT * FROM `dsw_events` WHERE active!='2' ";
      $events_run = mysqli_query($con,$events);

      if(mysqli_num_rows($events_run)>0){

        foreach($events_run as $event){

            ?>
    <tr>
      <td><?= $event['id'] ?></td>
      <td><?= $event['Title'] ?></td>
      <td><?= $event['Content'] ?></td>
      <td><img src="../uploads/events/<?= $event['image_name'] ?>" width="80px" height="80px" alt=""></td>
      <td><?= $event['active'] ?></td>
      <td><?= $event['created_at'] ?></td>
    </tr>
            <?php
        }
      }
      else{
          ?>

<tr>
    <td colspan="6">No Record FOund</td>
</tr>

          <?php
      }

      
      
      ?>

  </tbody>
</table>

    
</body>
</html>